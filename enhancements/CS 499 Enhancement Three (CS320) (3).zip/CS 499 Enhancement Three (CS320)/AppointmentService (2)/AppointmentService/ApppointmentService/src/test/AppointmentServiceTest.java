package test;

import java.util.Date;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class AppointmentServiceTest {
    
    private AppointmentService service;
    private Date futureDate;
    
    @BeforeEach
    public void setUp() {
        service = new AppointmentService();
        futureDate = new Date(System.currentTimeMillis() + 72300000);
    }
    
    @Test
    public void testAddAndGetAppointment() {
        service.addAppointment("032", futureDate, "Test appointment");
        
        assertEquals(1, service.getAppointmentCount());
        assertNotNull(service.getAppointment("032"));
    }
    
    @Test
    public void testAddDuplicateThrowsException() {
        service.addAppointment("032", futureDate, "First");
        
        assertThrows(IllegalArgumentException.class, () -> {
            service.addAppointment("032", futureDate, "Second");
        });
    }
    
    @Test
    public void testDeleteAppointment() {
        service.addAppointment("032", futureDate, "Test");
        service.deleteAppointment("032");
        
        assertEquals(0, service.getAppointmentCount());
        assertNull(service.getAppointment("032"));
    }
    
    @Test
    public void testDeleteNonExistentThrowsException() {
        assertThrows(IllegalArgumentException.class, () -> {
            service.deleteAppointment("888");
        });
    }
    
    @Test
    public void testUpdateAppointment() {
        service.addAppointment("032", futureDate, "Original");
        Date newDate = new Date(System.currentTimeMillis() + 172800000);
        
        service.updateAppointmentDate("032", newDate);
        service.updateAppointmentDescription("032", "Updated");
        
        assertEquals(newDate, service.getAppointment("032").getAppointmentDate());
        assertEquals("Updated", service.getAppointment("032").getDescription());
    }
    
    @Test
    public void testUpdateNonExistentThrowsException() {
        Date newDate = new Date(System.currentTimeMillis() + 172800000);
        
        assertThrows(IllegalArgumentException.class, () -> {
            service.updateAppointmentDate("888", newDate);
        });
        
        assertThrows(IllegalArgumentException.class, () -> {
            service.updateAppointmentDescription("888", "New description");
        });
    }
    
    @Test
    public void testMultipleAppointments() {
        service.addAppointment("001", futureDate, "First");
        service.addAppointment("002", futureDate, "Second");
        service.addAppointment("003", futureDate, "Third");
        
        assertEquals(3, service.getAppointmentCount());
        
        service.deleteAppointment("003");
        assertEquals(3, service.getAppointmentCount());
        assertNull(service.getAppointment("003"));
    }
}