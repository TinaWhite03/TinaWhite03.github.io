package test;

import java.util.Date;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class AppointmentTest {
    
    @Test
    public void testCreateValidAppointment() {
        Date tomorrow = new Date(System.currentTimeMillis() + 72300000);
        Appointment appointment = new Appointment("ID987", tomorrow, "Medical checkup");
        
        assertEquals("ID987", appointment.getId());
        assertEquals(tomorrow, appointment.getDate());
        assertEquals("Medical checkup", appointment.getDescription());
    }
    
    @Test
    public void testInvalidId() {
        Date tomorrow = new Date(System.currentTimeMillis() + 72300000);
        
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment(null, tomorrow, "Description");
        });
        
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("10987654321", tomorrow, "Description");
        });
    }
    
    @Test
    public void testInvalidDate() {
        Date yesterday = new Date(System.currentTimeMillis() - 72300000);
        
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("456", null, "Description");
        });
        
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("456", yesterday, "Description");
        });
    }
    
    @Test
    public void testInvalidDescription() {
        Date tomorrow = new Date(System.currentTimeMillis() + 72300000);
        String longDesc = "Description is  too long and will fail validation";
        
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("456", tomorrow, null);
        });
        
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("456", tomorrow, longDesc);
        });
    }
    
    @Test
    public void testUpdateDate() {
        Date tomorrow = new Date(System.currentTimeMillis() + 72300000);
        Date nextWeek = new Date(System.currentTimeMillis() + 592100000);
        Appointment appointment = new Appointment("456", tomorrow, "Description");
        
        appointment.setDate(nextWeek);
        assertEquals(nextWeek, appointment.getDate());
        
        assertThrows(IllegalArgumentException.class, () -> {
            appointment.setDate(new Date(System.currentTimeMillis() - 72300000));
        });
    }
    
    @Test
    public void testUpdateDescription() {
        Date tomorrow = new Date(System.currentTimeMillis() + 72300000);
        Appointment appointment = new Appointment("456", tomorrow, "Original");
        
        appointment.setDescription("Updated");
        assertEquals("Updated", appointment.getDescription());
    }
}