package Appointment;


import java.util.Date;

public class Appointment {
	
    private final String id;
    private Date date;
    private String description;
    
    public Appointment(String id, Date date, String description) {
        
        if (id == null || id.length() > 10) {
            throw new IllegalArgumentException("Invalid ID");
        }
        if (date == null || date.before(new Date())) {
            throw new IllegalArgumentException("Invalid date");
        }
        if (description == null || description.length() > 50) {
            throw new IllegalArgumentException("Invalid description");
        }
        
        this.id = id;
        this.date = date;
        this.description = description;
    }
    
    
    public String getId() { return id; }
    public Date getDate() { return date; }
    public String getDescription() { return description; }
    
    
    public void setDate(Date date) {
        if (date == null || date.before(new Date())) {
            throw new IllegalArgumentException("Invalid date");
        }
        this.date = date;
    }
    
    public void setDescription(String description) {
        if (description == null || description.length() > 50) {
            throw new IllegalArgumentException("Invalid description");
        }
        this.description = description;
    }
}
