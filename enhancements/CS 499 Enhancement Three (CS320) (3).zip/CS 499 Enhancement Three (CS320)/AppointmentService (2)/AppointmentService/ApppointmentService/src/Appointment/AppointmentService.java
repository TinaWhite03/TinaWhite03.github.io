package Appointment; 

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

public class AppointmentService {
    private Map<String, Appointment> appointments = new HashMap<>();
    
    public void add(String id, Date date, String description) {
        if (appointments.containsKey(id)) {
            throw new IllegalArgumentException("ID already exists");
        }
        appointments.put(id, new Appointment(id, date, description));
    }
    
    public void add(Appointment appointment) {
        String id = appointment.getId();
        if (appointments.containsKey(id)) {
            throw new IllegalArgumentException("ID already exists");
        }
        appointments.put(id, appointment);
    }
    
    public void remove(String id) {
        if (!appointments.containsKey(id)) {
            throw new IllegalArgumentException("ID not found");
        }
        appointments.remove(id);
    }
    
    public Appointment get(String id) {
        return appointments.get(id);
    }
    
    public void updateDate(String id, Date newDate) {
        Appointment appointment = appointments.get(id);
        if (appointment == null) {
            throw new IllegalArgumentException("ID not found");
        }
        appointment.setDate(newDate);
    }
    
    public void updateDescription(String id, String newDescription) {
        Appointment appointment = appointments.get(id);
        if (appointment == null) {
            throw new IllegalArgumentException("ID not found");
        }
        appointment.setDescription(newDescription);
    }
    
    public int count() {
        return appointments.size();
    }
}
