package task;

public class Task {
	private String taskID;
	private String name;
	private String description;
	
	 public Task(String taskID, String name, String description) {
	        
	        if (taskID == null || taskID.isEmpty()) {
	            throw new IllegalArgumentException("Task ID is required");
	        }
	        if (name == null || name.isEmpty()) {
	            throw new IllegalArgumentException("Name is required");
	        }
	        if (description == null || description.isEmpty()) {
	            throw new IllegalArgumentException("Description is required");
	        }
	        
	        this.taskID = taskID;
	        this.name = name;
	        this.description = description;
	    }
	    
	   
	    public String getTaskId() {
	        return taskID;
	    }
	    
	    public String getName() {
	        return name;
	    }
	    
	    public String getDescription() {
	        return description;
	    }
	    
	   
	    public void setName(String name) {
	        if (name == null || name.isEmpty()) {
	            throw new IllegalArgumentException("Name cannot be empty");
	        }
	        this.name = name;
	    }
	    
	    public void setDescription(String description) {
	        if (description == null || description.isEmpty()) {
	            throw new IllegalArgumentException("Description cannot be empty");
	        }
	        this.description = description;
	    }
	    
	    
	    public String toString() {
	        return "Task ID: " + taskID + ", Name: " + name + ", Description: " + description;
	    }
	}

