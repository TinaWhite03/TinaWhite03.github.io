package test;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import task.Task;
import task.TaskService;
import task.InMemoryTaskDAO;
import task.TaskDAO;

public class TaskServiceTest {
    private TaskService taskService;
    private TaskDAO taskDAO;

    @BeforeEach
    public void setUp() {
        taskDAO = new InMemoryTaskDAO();
        taskService = new TaskService(taskDAO);
    }

    @Test
    public void testAddAndGetTask() {
        Task task = new Task("1", "Task One", "Description One");
        taskService.addTask(task);
        
        Task result = taskService.getTask("1");
        assertEquals("1", result.getTaskId());
        assertEquals("Task One", result.getName());
    }

    @Test
    public void testAddDuplicateTask() {
        Task task1 = new Task("1", "Task One", "Description One");
        Task task2 = new Task("1", "Duplicate Task", "Description Two");
        
        taskService.addTask(task1);
        assertThrows(IllegalArgumentException.class, () -> taskService.addTask(task2));
    }

    @Test
    public void testDeleteTask() {
        Task task = new Task("5", "Task Five", "Description");
        taskService.addTask(task);
        
        taskService.deleteTask("5");
        assertNull(taskService.getTask("5"));
    }

    @Test
    public void testUpdateTaskName() {
        Task task = new Task("5", "Old Name", "Description");
        taskService.addTask(task);
        
        taskService.updateTaskName("5", "New Name");
        assertEquals("New Name", taskService.getTask("5").getName());
    }

    @Test
    public void testUpdateTaskDescription() {
        Task task = new Task("5", "Task Name", "Old Desc");
        taskService.addTask(task);
        
        taskService.updateTaskDescription("5", "New Desc");
        assertEquals("New Desc", taskService.getTask("5").getDescription());
    }

   
    @Test
    public void testDAOAddAndGetTask() {
        Task task = new Task("10", "DAO Task", "DAO Desc");
        taskDAO.addTask(task);
        Task result = taskDAO.getTask("10");
        assertEquals("DAO Task", result.getName());
    }
}