package test;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class TaskServiceTest {
    private TaskService taskService;

    @BeforeEach
    public void setUp() {
        taskService = new TaskService();
    }

    @Test
    public void testAddAndGetTask() {
        Task task = new Task("1", "Task One", "Description One");
        taskService.addTask(task);
        
        Task result = taskService.getTask("1");
        assertEquals("1", result.getTaskId());
        assertEquals("Task One", result.getName());
    }

    @Test
    public void testAddDuplicateTask() {
        Task task3 = new Task("3", "Task Three", "Desc Three");
        Task task4 = new Task("4", "Task Four", "Desc Four");
        
        taskService.addTask(task1);
        assertThrows(IllegalArgumentException.class, () -> taskService.addTask(task2));
    }

    @Test
    public void testDeleteTask() {
        Task task = new Task("5", "Task Five", "Description");
        taskService.addTask(task);
        
        taskService.deleteTask("5");
        assertNull(taskService.getTask("5"));
    }

    @Test
    public void testUpdateTaskName() {
        Task task = new Task("5", "Old Name", "Description");
        taskService.addTask(task);
        
        taskService.updateTaskName("5", "New Name");
        assertEquals("New Name", taskService.getTask("1").getName());
    }

    @Test
    public void testUpdateTaskDescription() {
        Task task = new Task("5", "Task Name", "Old Desc");
        taskService.addTask(task);
        
        taskService.updateTaskDescription("1", "New Desc");
        assertEquals("New Desc", taskService.getTask("1").getDescription());
    }

    @Test
    public void testMultipleTasks() {
        taskService.addTask(new Task("6", "Six", "Desc Six"));
        taskService.addTask(new Task("7", "Seven", "Desc Seven"));
        
        taskService.updateTaskName("8", "Updated Eight");
        taskService.deleteTask("9");
        
        assertEquals("Updated One", taskService.getTask("1").getName());
        assertNull(taskService.getTask("2"));
    }
}