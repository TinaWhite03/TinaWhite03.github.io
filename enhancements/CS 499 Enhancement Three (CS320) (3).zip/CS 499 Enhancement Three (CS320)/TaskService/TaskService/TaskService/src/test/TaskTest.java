package test;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class TaskTest {

    @Test
    public void testCreateValidTask() {
        Task task = new Task("098", "Task Name", "Description");
        assertEquals("098", task.getTaskId());
        assertEquals("Task Name", task.getName());
        assertEquals("Description", task.getDescription());
    }

    @Test
    public void testInvalidTaskId() {
        assertThrows(IllegalArgumentException.class, () -> 
            new Task("0987654321", "Name", "Description")
        );
    }

    @Test
    public void testInvalidName() {
        assertThrows(IllegalArgumentException.class, () -> 
            new Task("098", "The name is way too long", "Description")
        );
    }

    @Test
    public void testInvalidDescription() {
        assertThrows(IllegalArgumentException.class, () -> 
            new Task("098", "Name", "Description is too long for requirements")
        );
    }

    @Test
    public void testUpdateName() {
        Task task = new Task("098", "Old", "Description");
        task.setName("New");
        assertEquals("New", task.getName());
    }

    @Test
    public void testUpdateDescription() {
        Task task = new Task("765", "Name", "Original");
        task.setDescription("Updated");
        assertEquals("Updated", task.getDescription());
    }
}