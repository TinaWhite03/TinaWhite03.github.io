package task;

import java.util.HashMap;
import java.util.Map;

public class InMemoryTaskDAO implements TaskDAO {
    private final Map<String, Task> tasks = new HashMap<>();

    @Override
    public void addTask(Task task) {
        if (tasks.containsKey(task.getTaskId())) {
            throw new IllegalArgumentException("Task ID already exists");
        }
        tasks.put(task.getTaskId(), task);
    }

    @Override
    public void deleteTask(String taskId) {
        if (!tasks.containsKey(taskId)) {
            throw new IllegalArgumentException("Task not found");
        }
        tasks.remove(taskId);
    }

    @Override
    public void updateTaskName(String taskId, String newName) {
        Task task = tasks.get(taskId);
        if (task == null) {
            throw new IllegalArgumentException("Task not found");
        }
        task.setName(newName);
    }

    @Override
    public void updateTaskDescription(String taskId, String newDescription) {
        Task task = tasks.get(taskId);
        if (task == null) {
            throw new IllegalArgumentException("Task not found");
        }
        task.setDescription(newDescription);
    }

    @Override
    public Task getTask(String taskId) {
        return tasks.get(taskId);
    }

    @Override
    public Map<String, Task> getAllTasks() {
        return new HashMap<>(tasks); // Return a copy for data integrity
    }
}