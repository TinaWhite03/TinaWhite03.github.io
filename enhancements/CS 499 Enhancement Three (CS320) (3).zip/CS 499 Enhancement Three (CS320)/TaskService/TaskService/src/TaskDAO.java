package task;

import java.util.Map;

public interface TaskDAO {
    void addTask(Task task);
    void deleteTask(String taskId);
    void updateTaskName(String taskId, String newName);
    void updateTaskDescription(String taskId, String newDescription);
    Task getTask(String taskId);
    Map<String, Task> getAllTasks();
}