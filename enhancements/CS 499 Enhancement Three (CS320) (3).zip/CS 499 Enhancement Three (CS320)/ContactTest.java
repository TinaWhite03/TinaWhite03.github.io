package test;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import com.contactservice.Contact;

public class ContactTest {

    @Test
    public void testValidContactCreation() {
        Contact contact = new Contact("123", "John", "Doe", "1234567890", "123 Main St");
        
        assertEquals("123", contact.getContactID());
        assertEquals("John", contact.getFirstName());
        assertEquals("Doe", contact.getLastName());
        assertEquals("1234567890", contact.getPhone());
        assertEquals("123 Main St", contact.getAddress());
    }

    @Test
    public void testContactIDValidation() {
        
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact(null, "Tasha", "Smith", "1234567890", "123 Main St");
        });
        
        
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("12345678901", "Tasha", "Smith", "1234567890", "123 Main St");
        });
    }

    @Test
    public void testFirstNameValidation() {
        
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("123", null, "Smith", "1234567890", "123 Main St");
        });
        
        
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("123", "Williamson", "Doe", "1234567890", "123 Main St");
        });
    }

    @Test
    public void testLastNameValidation() {
      
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("123", "Tasha", null, "1234567890", "123 Main St");
        });
        
       
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("123", "Joe", "Johnson", "1234567890", "123 Main St");
        });
    }

    @Test
    public void testPhoneValidation() {
       
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("123", "Tasha", "Smith", null, "123 Main St");
        });
        
        
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("123", "Tasha", "Smith", "12345", "123 Main St");
        });
    }

    @Test
    public void testAddressValidation() {
        
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("123", "Tasha", "Smith", "1234567890", null);
        });
        
        
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("123", "Tasha", "Smith", "1234567890", 
                "This address is way too long and exceeds thirty characters");
        });
    }

    @Test
    public void testSettersWithValidData() {
        Contact contact = new Contact("123", "Tasha", "Smith", "1234567890", "123 Main St");
        
        contact.setFirstName("Jane");
        contact.setLastName("Smith");
        contact.setPhone("0987654321");
        contact.setAddress("456 Oak Ave");
        
        assertEquals("Jane", contact.getFirstName());
        assertEquals("Smith", contact.getLastName());
        assertEquals("0987654321", contact.getPhone());
        assertEquals("456 Oak Ave", contact.getAddress());
    }

    @Test
    public void testSettersWithInvalidData() {
        Contact contact = new Contact("123", "Tasha", "Smith", "1234567890", "123 Main St");
        
        
        assertThrows(IllegalArgumentException.class, () -> {
            contact.setFirstName(null);
        });
        
        assertThrows(IllegalArgumentException.class, () -> {
            contact.setPhone("123"); 
        });
    }
}