package com.contactservice;

import java.util.HashMap;
import java.util.Map;

public class ContactService {
    private Map<String, Contact> contacts;

    public ContactService() {
        this.contacts = new HashMap<>();
    }

   
    public void addContact(Contact contact) {
        if (contact == null) {
            throw new IllegalArgumentException("Contact cannot be null");
        }
        
        String contactID = contact.getContactID();
        if (contacts.containsKey(contactID)) {
            throw new IllegalArgumentException("Contact ID already exists: " + contactID);
        }
        
        contacts.put(contactID, contact);
    }

    
    public void deleteContact(String contactID) {
        if (contactID == null) {
            throw new IllegalArgumentException("Contact ID cannot be null");
        }
        
        if (!contacts.containsKey(contactID)) {
            throw new IllegalArgumentException("Contact not found with ID: " + contactID);
        }
        
        contacts.remove(contactID);
    }

   
    public void updateFirstName(String contactID, String firstName) {
        if (contactID == null) {
            throw new IllegalArgumentException("Contact ID cannot be null");
        }
        
        Contact contact = contacts.get(contactID);
        if (contact == null) {
            throw new IllegalArgumentException("Contact not found with ID: " + contactID);
        }
        
        contact.setFirstName(firstName);
    }

   
    public void updateLastName(String contactID, String lastName) {
        if (contactID == null) {
            throw new IllegalArgumentException("Contact ID cannot be null");
        }
        
        Contact contact = contacts.get(contactID);
        if (contact == null) {
            throw new IllegalArgumentException("Contact not found with ID: " + contactID);
        }
        
        contact.setLastName(lastName);
    }

    
    public void updatePhone(String contactID, String phone) {
        if (contactID == null) {
            throw new IllegalArgumentException("Contact ID cannot be null");
        }
        
        Contact contact = contacts.get(contactID);
        if (contact == null) {
            throw new IllegalArgumentException("Contact not found with ID: " + contactID);
        }
        
        contact.setPhone(phone);
    }

    
    public void updateAddress(String contactID, String address) {
        if (contactID == null) {
            throw new IllegalArgumentException("Contact ID cannot be null");
        }
        
        Contact contact = contacts.get(contactID);
        if (contact == null) {
            throw new IllegalArgumentException("Contact not found with ID: " + contactID);
        }
        
        contact.setAddress(address);
    }

   
    public Contact getContact(String contactID) {
        if (contactID == null) {
            throw new IllegalArgumentException("Contact ID cannot be null");
        }
        
        return contacts.get(contactID);
    }

   
    public boolean contactExists(String contactID) {
        return contacts.containsKey(contactID);
    }

  
    public Map<String, Contact> getAllContacts() {
        return new HashMap<>(contacts); 
    }
}