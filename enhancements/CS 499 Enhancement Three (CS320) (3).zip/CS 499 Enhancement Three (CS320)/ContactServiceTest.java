package test;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.BeforeEach;
import static org.junit.jupiter.api.Assertions.*;

import com.contactservice.Contact;
import com.contactservice.ContactService;

public class ContactServiceTest {
    
    private ContactService contactService; 
    
    @BeforeEach
    public void setUp() {
        contactService = new ContactService();
    }
    
    @Test
    public void testAddAndGetContact() {
        Contact contact = new Contact("1", "Tasha", "Smith", "1234567890", "123 Main St");
        contactService.addContact(contact);
        
        Contact retrieved = contactService.getContact("1");
        assertNotNull(retrieved);
        assertEquals("Tasha", retrieved.getFirstName());
        assertEquals("Smith", retrieved.getLastName());
    }
    
    @Test
    public void testDeleteContact() {
        Contact contact = new Contact("1", "Tasha", "Smith", "1234567890", "123 Main St");
        contactService.addContact(contact);
        
        contactService.deleteContact("1");
        assertNull(contactService.getContact("1"));
    }
    
    @Test
    public void testUpdateContactFields() {
        Contact contact = new Contact("1", "Tasha", "Smith", "1234567890", "123 Main St");
        contactService.addContact(contact);
        
        contactService.updateFirstName("1", "Jane");
        contactService.updateLastName("1", "Doe");
        contactService.updatePhone("1", "0987654321");
        
        Contact updated = contactService.getContact("1");
        assertEquals("Jane", updated.getFirstName());
        assertEquals("Doe", updated.getLastName());
        assertEquals("0987654321", updated.getPhone());
    }
    
    @Test
    public void testAddDuplicateContact() {
        Contact contact1 = new Contact("1", "Tasha", "Smith", "1234567890", "123 Main St");
        Contact contact2 = new Contact("1", "Jane", "Doe", "0987654321", "456 Oak St");
        
        contactService.addContact(contact1);
        
        assertThrows(IllegalArgumentException.class, () -> {
            contactService.addContact(contact2);
        });
    }
    
    @Test
    public void testUpdateNonExistentContact() {
        assertThrows(IllegalArgumentException.class, () -> {
            contactService.updateFirstName("999", "Jane");
        });
    }
}