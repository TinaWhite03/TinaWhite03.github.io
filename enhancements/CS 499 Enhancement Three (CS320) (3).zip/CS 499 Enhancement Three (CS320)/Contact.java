package com.contactservice;

public class Contact {
    private final String contactID;
    private String firstName, lastName, phone, address;

    public Contact(String contactID,
                   String firstName,
                   String lastName,
                   String phone, 
                   String address) {
        
        if (contactID == null || contactID.length() > 10) { 
            throw new IllegalArgumentException("Contact ID cannot be null and cannot be longer than 10 characters");
        }
        if (firstName == null || firstName.length() > 10) { 
            throw new IllegalArgumentException("First name cannot be null and cannot be longer than 10 characters");
        }
        if (lastName == null || lastName.length() > 10) {
            throw new IllegalArgumentException("Last name cannot be null and cannot be longer than 10 characters");
        }
        if (phone == null || phone.length() != 10) {
            throw new IllegalArgumentException("Phone must be exactly 10 digits and cannot be null");
        }
        if (address == null || address.length() > 30) {
            throw new IllegalArgumentException("Address cannot be null and cannot be longer than 30 characters");
        }

        this.contactID = contactID;
        this.firstName = firstName;
        this.lastName = lastName;
        this.phone = phone;
        this.address = address;
    }

    public String getContactID() { return contactID; }
    public String getFirstName() { return firstName; }
    public String getLastName() { return lastName; }
    public String getPhone() { return phone; }
    public String getAddress() { return address; }

    public void setFirstName(String firstName) {
        if (firstName == null || firstName.length() > 10) { 
            throw new IllegalArgumentException("First name cannot be null and cannot be longer than 10 characters");
        }
        this.firstName = firstName;
    }

    public void setLastName(String lastName) {
        if (lastName == null || lastName.length() > 10) {
            throw new IllegalArgumentException("Last name cannot be null and cannot be longer than 10 characters");
        }
        this.lastName = lastName;
    }

    public void setPhone(String phone) {
        if (phone == null || phone.length() != 10) {
            throw new IllegalArgumentException("Phone must be exactly 10 digits and cannot be null");
        }
        this.phone = phone;
    }

    public void setAddress(String address) {
        if (address == null || address.length() > 30) {
            throw new IllegalArgumentException("Address cannot be null and cannot be longer than 30 characters");
        }
        this.address = address;
    }
}