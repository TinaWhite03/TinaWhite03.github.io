﻿///////////////////////////////////////////////////////////////////////////////
// shadermanager.cpp
// ============
// manage the loading and rendering of 3D scenes
//
//  AUTHOR: Brian Battersby - SNHU Instructor / Computer Science
//	Created for CS-330-Computational Graphics and Visualization, Nov. 1st, 2023
///////////////////////////////////////////////////////////////////////////////

#include "SceneManager.h"


#ifndef STB_IMAGE_IMPLEMENTATION
#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"
#endif

#include <glm/gtx/transform.hpp>

// declaration of global variables
namespace
{
	const char* g_ModelName = "model";
	const char* g_ColorValueName = "objectColor";
	const char* g_TextureValueName = "objectTexture";
	const char* g_UseTextureName = "bUseTexture";
	const char* g_UseLightingName = "bUseLighting";
}

/***********************************************************
 *  SceneManager()
 *
 *  The constructor for the class
 ***********************************************************/
SceneManager::SceneManager(ShaderManager *pShaderManager)
{
	m_pShaderManager = pShaderManager;
	m_basicMeshes = new ShapeMeshes();
	m_pCamera = nullptr; // Initialize to null
}

/***********************************************************
 *  ~SceneManager()
 *
 *  The destructor for the class
 ***********************************************************/
SceneManager::~SceneManager()
{
	m_pShaderManager = NULL;
	delete m_basicMeshes;
	m_basicMeshes = NULL;
}

/***********************************************************
 *  CreateGLTexture()
 *
 *  This method is used for loading textures from image files,
 *  configuring the texture mapping parameters in OpenGL,
 *  generating the mipmaps, and loading the read texture into
 *  the next available texture slot in memory.
 ***********************************************************/
bool SceneManager::CreateGLTexture(const char* filename, std::string tag)
{
	int width = 0;
	int height = 0;
	int colorChannels = 0;
	GLuint textureID = 0;

	// indicate to always flip images vertically when loaded
	stbi_set_flip_vertically_on_load(true);

	// try to parse the image data from the specified image file
	unsigned char* image = stbi_load(
		filename,
		&width,
		&height,
		&colorChannels,
		0);

	// if the image was successfully read from the image file
	if (image)
	{
		std::cout << "Successfully loaded image:" << filename << ", width:" << width << ", height:" << height << ", channels:" << colorChannels << std::endl;

		glGenTextures(1, &textureID);
		glBindTexture(GL_TEXTURE_2D, textureID);

		// set the texture wrapping parameters
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
		// set texture filtering parameters
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

		// if the loaded image is in RGB format
		if (colorChannels == 3)
			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB8, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, image);
		// if the loaded image is in RGBA format - it supports transparency
		else if (colorChannels == 4)
			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, image);
		else
		{
			std::cout << "Not implemented to handle image with " << colorChannels << " channels" << std::endl;
			return false;
		}

		// generate the texture mipmaps for mapping textures to lower resolutions
		glGenerateMipmap(GL_TEXTURE_2D);

		// free the image data from local memory
		stbi_image_free(image);
		glBindTexture(GL_TEXTURE_2D, 0); // Unbind the texture

		// register the loaded texture and associate it with the special tag string
		m_textureIDs[m_loadedTextures].ID = textureID;
		m_textureIDs[m_loadedTextures].tag = tag;
		m_loadedTextures++;

		return true;
	}

	std::cout << "Could not load image:" << filename << std::endl;

	// Error loading the image
	return false;
}

/***********************************************************
 *  BindGLTextures()
 *
 *  This method is used for binding the loaded textures to
 *  OpenGL texture memory slots.  There are up to 16 slots.
 ***********************************************************/
void SceneManager::BindGLTextures()
{
	for (int i = 0; i < m_loadedTextures; i++)
	{
		// bind textures on corresponding texture units
		glActiveTexture(GL_TEXTURE0 + i);
		glBindTexture(GL_TEXTURE_2D, m_textureIDs[i].ID);
	}
}

/***********************************************************
 *  DestroyGLTextures()
 *
 *  This method is used for freeing the memory in all the
 *  used texture memory slots.
 ***********************************************************/
void SceneManager::DestroyGLTextures()
{
	for (int i = 0; i < m_loadedTextures; i++)
	{
		glGenTextures(1, &m_textureIDs[i].ID);
	}
	m_loadedTextures = 0;
}

/***********************************************************
 *  FindTextureID()
 *
 *  This method is used for getting an ID for the previously
 *  loaded texture bitmap associated with the passed in tag.
 ***********************************************************/
int SceneManager::FindTextureID(std::string tag)
{
	int textureID = -1;
	int index = 0;
	bool bFound = false;

	while ((index < m_loadedTextures) && (bFound == false))
	{
		if (m_textureIDs[index].tag.compare(tag) == 0)
		{
			textureID = m_textureIDs[index].ID;
			bFound = true;
		}
		else
			index++;
	}

	return(textureID);
}

/***********************************************************
 *  FindTextureSlot()
 *
 *  This method is used for getting a slot index for the previously
 *  loaded texture bitmap associated with the passed in tag.
 ***********************************************************/
int SceneManager::FindTextureSlot(std::string tag)
{
	int textureSlot = -1;
	int index = 0;
	bool bFound = false;

	while ((index < m_loadedTextures) && (bFound == false))
	{
		if (m_textureIDs[index].tag.compare(tag) == 0)
		{
			textureSlot = index;
			bFound = true;
		}
		else
			index++;
	}

	return(textureSlot);
}

/***********************************************************
 *  FindMaterial()
 *
 *  This method is used for getting a material from the previously
 *  defined materials list that is associated with the passed in tag.
 ***********************************************************/
bool SceneManager::FindMaterial(std::string tag, OBJECT_MATERIAL& material)
{
	if (m_objectMaterials.size() == 0)
	{
		return(false);
	}

	int index = 0;
	bool bFound = false;
	while ((index < m_objectMaterials.size()) && (bFound == false))
	{
		if (m_objectMaterials[index].tag.compare(tag) == 0)
		{
			bFound = true;
			material.ambientColor = m_objectMaterials[index].ambientColor;
			material.ambientStrength = m_objectMaterials[index].ambientStrength;
			material.diffuseColor = m_objectMaterials[index].diffuseColor;
			material.specularColor = m_objectMaterials[index].specularColor;
			material.shininess = m_objectMaterials[index].shininess;
		}
		else
		{
			index++;
		}
	}

	return(true);
}

/***********************************************************
 *  SetTransformations()
 *
 *  This method is used for setting the transform buffer
 *  using the passed in transformation values.
 ***********************************************************/
void SceneManager::SetTransformations(
	glm::vec3 scaleXYZ,
	float XrotationDegrees,
	float YrotationDegrees,
	float ZrotationDegrees,
	glm::vec3 positionXYZ)
{
	// variables for this method
	glm::mat4 modelView;
	glm::mat4 scale;
	glm::mat4 rotationX;
	glm::mat4 rotationY;
	glm::mat4 rotationZ;
	glm::mat4 translation;

	// set the scale value in the transform buffer
	scale = glm::scale(scaleXYZ);
	// set the rotation values in the transform buffer
	rotationX = glm::rotate(glm::radians(XrotationDegrees), glm::vec3(1.0f, 0.0f, 0.0f));
	rotationY = glm::rotate(glm::radians(YrotationDegrees), glm::vec3(0.0f, 1.0f, 0.0f));
	rotationZ = glm::rotate(glm::radians(ZrotationDegrees), glm::vec3(0.0f, 0.0f, 1.0f));
	// set the translation value in the transform buffer
	translation = glm::translate(positionXYZ);

	modelView = translation * rotationX * rotationY * rotationZ * scale;

	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setMat4Value(g_ModelName, modelView);
	}
}

/***********************************************************
 *  SetShaderColor()
 *
 *  This method is used for setting the passed in color
 *  into the shader for the next draw command
 ***********************************************************/
void SceneManager::SetShaderColor(
	float redColorValue,
	float greenColorValue,
	float blueColorValue,
	float alphaValue)
{
	// variables for this method
	glm::vec4 currentColor;

	currentColor.r = redColorValue;
	currentColor.g = greenColorValue;
	currentColor.b = blueColorValue;
	currentColor.a = alphaValue;

	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setIntValue(g_UseTextureName, false);
		m_pShaderManager->setVec4Value(g_ColorValueName, currentColor);
	}
}

/***********************************************************
 *  SetShaderTexture()
 *
 *  This method is used for setting the texture data
 *  associated with the passed in ID into the shader.
 ***********************************************************/
void SceneManager::SetShaderTexture(
	std::string textureTag)
{
	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setIntValue(g_UseTextureName, true);

		int textureID = -1;
		textureID = FindTextureSlot(textureTag);
		m_pShaderManager->setSampler2DValue(g_TextureValueName, textureID);
	}
}

/***********************************************************
 *  SetTextureUVScale()
 *
 *  This method is used for setting the texture UV scale
 *  values into the shader.
 ***********************************************************/
void SceneManager::SetTextureUVScale(float u, float v)
{
	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setVec2Value("UVscale", glm::vec2(u, v));
	}
}

/***********************************************************
 *  SetShaderMaterial()
 *
 *  This method is used for passing the material values
 *  into the shader.
 ***********************************************************/
void SceneManager::SetShaderMaterial(
	std::string materialTag)
{
	if (m_objectMaterials.size() > 0)
	{
		OBJECT_MATERIAL material;
		bool bReturn = false;

		bReturn = FindMaterial(materialTag, material);
		if (bReturn == true)
		{
			m_pShaderManager->setVec3Value("material.ambientColor", material.ambientColor);
			m_pShaderManager->setFloatValue("material.ambientStrength", material.ambientStrength);
			m_pShaderManager->setVec3Value("material.diffuseColor", material.diffuseColor);
			m_pShaderManager->setVec3Value("material.specularColor", material.specularColor);
			m_pShaderManager->setFloatValue("material.shininess", material.shininess);
		}
	}
}



/**************************************************************/
/*** STUDENTS CAN MODIFY the code in the methods BELOW for  ***/
/*** preparing and rendering their own 3D replicated scenes.***/
/*** Please refer to the code in the OpenGL sample project  ***/
/*** for assistance.                                        ***/
/**************************************************************/

/***********************************************************
 *  LoadSceneTextures()
 *
 *  This method loads all textures needed for the scene
 ***********************************************************/
void SceneManager::LoadSceneTextures()
{
	bool bReturn = false;

	// First, try to load the greencarpet texture
	std::cout << "Attempting to load carpet texture..." << std::endl;
	bReturn = CreateGLTexture("../../Utilities/textures/echo.jpg", "carpet");

	if (!bReturn) {
		std::cout << "Warning: Could not load greencarpet.jpg. Trying alternatives..." << std::endl;
		// Try alternative names if greencarpet.jpg doesn't exist
		bReturn = CreateGLTexture("../../Utilities/textures/echo.jpg", "carpet") ||
			CreateGLTexture("../../Utilities/textures/rug.jpg", "carpet");
	}
	bReturn = CreateGLTexture("../../Utilities/textures/plaingold", "wall");

	// Load other textures you need
	CreateGLTexture("../../Utilities/textures/pavers.jpg", "pavers");
	CreateGLTexture("../../Utilities/textures/olivewood.jpg", "wood");
	CreateGLTexture("../../Utilities/textures/tilesf2.jpg", "box");
	CreateGLTexture("../../Utilities/textures/static.jpg", "tv_screen");


	// Load carpet
	bReturn = CreateGLTexture("../../Utilities/textures/echo.jpg", "carpet");

	// Load wall texture
	bReturn = CreateGLTexture("../../Utilities/textures/plaingold.jpg", "wall");

	// Load other textures you use
	bReturn = CreateGLTexture("../../Utilities/textures/pavers.jpg", "pavers");
	bReturn = CreateGLTexture("../../Utilities/textures/gold-seamless-texture.jpg", "metal");
	bReturn = CreateGLTexture("../../Utilities/textures/olivewood.jpg", "wood");
	bReturn = CreateGLTexture("../../Utilities/textures/tilesf2.jpg", "box");
	bReturn = CreateGLTexture("../../Utilities/textures/stainedglass.jpg", "glass");
	bReturn = CreateGLTexture("../../Utilities/textures/abstract.jpg", "abstract");
	bReturn = CreateGLTexture("../../Utilities/textures/static.jpg", "tv_screen");

	// After loading all textures, bind them to texture units
	BindGLTextures();
}

/***********************************************************
 *  DefineObjectMaterials()
 *
 *  This method is used for configuring the various material
 *  settings for all of the objects in the 3D scene.
 ***********************************************************/
void SceneManager::DefineObjectMaterials()
{

	// ========== ADD CARPET MATERIAL ==========
	OBJECT_MATERIAL carpetMaterial;
	carpetMaterial.ambientColor = glm::vec3(0.15f, 0.2f, 0.12f);  // Greenish
	carpetMaterial.ambientStrength = 0.5f;
	carpetMaterial.diffuseColor = glm::vec3(0.3f, 0.4f, 0.25f);
	carpetMaterial.specularColor = glm::vec3(0.05f, 0.05f, 0.05f);  // Low specular (carpet is matte)
	carpetMaterial.shininess = 1.0f;  // Very low shininess
	carpetMaterial.tag = "carpet";
	m_objectMaterials.push_back(carpetMaterial);

	// ========== ADD WALL MATERIAL ==========
	OBJECT_MATERIAL wallMaterial;
	wallMaterial.ambientColor = glm::vec3(0.25f, 0.23f, 0.21f);  // Neutral wall color
	wallMaterial.ambientStrength = 0.4f;
	wallMaterial.diffuseColor = glm::vec3(0.5f, 0.47f, 0.44f);
	wallMaterial.specularColor = glm::vec3(0.08f, 0.08f, 0.08f);  // Walls are not shiny
	wallMaterial.shininess = 2.0f;
	wallMaterial.tag = "wall";
	m_objectMaterials.push_back(wallMaterial);

	// Light wood material for shelves
	OBJECT_MATERIAL lightWoodMaterial;
	lightWoodMaterial.ambientColor = glm::vec3(0.35f, 0.28f, 0.22f);
	lightWoodMaterial.ambientStrength = 0.4f;
	lightWoodMaterial.diffuseColor = glm::vec3(0.55f, 0.45f, 0.35f);
	lightWoodMaterial.specularColor = glm::vec3(0.15f, 0.15f, 0.15f);
	lightWoodMaterial.shininess = 8.0f;
	lightWoodMaterial.tag = "light_wood";
	m_objectMaterials.push_back(lightWoodMaterial);

	// Dark wood material for main TV stand base
	OBJECT_MATERIAL darkWoodMaterial;
	darkWoodMaterial.ambientColor = glm::vec3(0.15f, 0.1f, 0.08f);
	darkWoodMaterial.ambientStrength = 0.3f;
	darkWoodMaterial.diffuseColor = glm::vec3(0.25f, 0.18f, 0.12f);
	darkWoodMaterial.specularColor = glm::vec3(0.05f, 0.05f, 0.05f);
	darkWoodMaterial.shininess = 6.0f;
	darkWoodMaterial.tag = "DarkWood";
	m_objectMaterials.push_back(darkWoodMaterial);

	// Wood texture material for accents
	OBJECT_MATERIAL woodTextureMaterial;
	woodTextureMaterial.ambientColor = glm::vec3(0.28f, 0.22f, 0.18f);
	woodTextureMaterial.ambientStrength = 0.35f;
	woodTextureMaterial.diffuseColor = glm::vec3(0.45f, 0.35f, 0.28f);
	woodTextureMaterial.specularColor = glm::vec3(0.1f, 0.1f, 0.1f);
	woodTextureMaterial.shininess = 5.0f;
	woodTextureMaterial.tag = "wood_texture";
	m_objectMaterials.push_back(woodTextureMaterial);

	OBJECT_MATERIAL oliveWoodMaterial;
	oliveWoodMaterial.ambientColor = glm::vec3(0.25f, 0.22f, 0.18f);  // Olive wood color
	oliveWoodMaterial.ambientStrength = 0.4f;
	oliveWoodMaterial.diffuseColor = glm::vec3(0.45f, 0.38f, 0.28f);  // Olive wood diffuse
	oliveWoodMaterial.specularColor = glm::vec3(0.12f, 0.1f, 0.08f);  // Low specular
	oliveWoodMaterial.shininess = 6.0f;  // Medium-low shininess for wood
	oliveWoodMaterial.tag = "olivewood_floor";
	m_objectMaterials.push_back(oliveWoodMaterial);

		
}

/***********************************************************
 *  SetupSceneLights()
 *
 *  This method is used to add and configure the various light
 *  sources that will add more realism to the 3D scene.
 ***********************************************************/
void SceneManager::SetupSceneLights()
{
	/*** SOFT AFTERNOON SUNLIGHT - Warm, gentle main light ***/
	m_pShaderManager->setVec3Value("lightSources[0].position", -3.0f, 8.0f, 2.0f);  // Angled like afternoon sun
	m_pShaderManager->setVec3Value("lightSources[0].ambientColor", 0.15f, 0.15f, 0.12f);  // Warm ambient fill
	m_pShaderManager->setVec3Value("lightSources[0].diffuseColor", 0.4f, 0.35f, 0.25f);  // Warm golden light
	m_pShaderManager->setVec3Value("lightSources[0].specularColor", 0.5f, 0.45f, 0.35f);  // Soft warm highlights
	m_pShaderManager->setFloatValue("lightSources[0].focalStrength", 80.0f);  // Very wide, soft spread like sunlight
	m_pShaderManager->setFloatValue("lightSources[0].specularIntensity", 0.3f);  // Subtle highlights

	/*** BOUNCE LIGHT - Subtle light from floor/ceiling ***/
	m_pShaderManager->setVec3Value("lightSources[1].position", 0.0f, 3.0f, 0.0f);  // Centered mid-height
	m_pShaderManager->setVec3Value("lightSources[1].ambientColor", 0.05f, 0.06f, 0.05f);  // Neutral bounce
	m_pShaderManager->setVec3Value("lightSources[1].diffuseColor", 0.12f, 0.12f, 0.1f);  // Very soft fill
	m_pShaderManager->setVec3Value("lightSources[1].specularColor", 0.15f, 0.15f, 0.12f);
	m_pShaderManager->setFloatValue("lightSources[1].focalStrength", 100.0f);  // Extremely wide and soft
	m_pShaderManager->setFloatValue("lightSources[1].specularIntensity", 0.1f);  // Almost no specular

	/*** ACCENT WARMTH - Subtle warm accents ***/
	m_pShaderManager->setVec3Value("lightSources[2].position", -2.0f, 1.5f, 3.0f);  // Low, warm accent
	m_pShaderManager->setVec3Value("lightSources[2].ambientColor", 0.02f, 0.018f, 0.01f);  // Very warm tint
	m_pShaderManager->setVec3Value("lightSources[2].diffuseColor", 0.1f, 0.08f, 0.05f);  // Golden warm
	m_pShaderManager->setVec3Value("lightSources[2].specularColor", 0.12f, 0.1f, 0.06f);
	m_pShaderManager->setFloatValue("lightSources[2].focalStrength", 25.0f);  // Soft focus
	m_pShaderManager->setFloatValue("lightSources[2].specularIntensity", 0.2f);
}

/***********************************************************
 *  PrepareScene()
 *
 *  This method is used for preparing the 3D scene by loading
 *  the shapes, textures in memory to support the 3D scene 
 *  rendering
 ***********************************************************/
void SceneManager::PrepareScene()
{
	std::cout << "=== PREPARING SCENE ===" << std::endl;

	// Load all textures
	LoadSceneTextures();

	// Debug: List all loaded textures
	std::cout << "\n=== LOADED TEXTURES ===" << std::endl;
	for (int i = 0; i < m_loadedTextures; i++) {
		std::cout << "Texture " << i << ": " << m_textureIDs[i].tag << std::endl;
	}

	// Define materials for lighting
	DefineObjectMaterials();

	// Setup lighting
	SetupSceneLights();

	// only one instance of a particular mesh needs to be
	// loaded in memory no matter how many times it is drawn
	// in the rendered 3D scene

	m_basicMeshes->LoadPlaneMesh();    // For flat surfaces like floors
	m_basicMeshes->LoadBoxMesh();      // For 3D objects like walls, furniture
	m_basicMeshes->LoadSphereMesh();   // For spherical objects
	m_basicMeshes->LoadCylinderMesh(); // For cylindrical objects

	std::cout << "=== SCENE PREPARED ===" << std::endl;
}

/***********************************************************
 *  RenderScene()
 *
 *  This method is used for rendering the 3D scene by 
 *  transforming and drawing the basic 3D shapes
 ***********************************************************/
void SceneManager::RenderScene()
{
	BindGLTextures();

	// declare the variables for the transformations
	glm::vec3 scaleXYZ;
	float XrotationDegrees = 0.0f;
	float YrotationDegrees = 0.0f;
	float ZrotationDegrees = 0.0f;
	glm::vec3 positionXYZ;

	/*** Set needed transformations before drawing the basic mesh.  ***/
	/*** This same ordering of code should be used for transforming ***/
	/*** and drawing all the basic 3D shapes.						***/
	/******************************************************************/
	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(20.0f, 1.0f, 10.0f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(0.0f, 0.0f, 0.0f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	/*** FLOOR WITH CARPET IN THE MIDDLE ***/

	// First, draw the main floor (wood or concrete)
	std::cout << "Rendering main floor..." << std::endl;

	scaleXYZ = glm::vec3(40.0f, 0.1f, 20.0f);
	positionXYZ = glm::vec3(0.0f, 0.0f, 0.0f);

	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);

	// Use wood or concrete texture for the main floor
	SetShaderTexture("wood_floor");  // Or "concrete" for a different look
	SetShaderMaterial("wood_floor");
	SetTextureUVScale(8.0f, 4.0f);  // Adjust pattern scale for wood planks

	m_basicMeshes->DrawBoxMesh();
	std::cout << "Main floor rendered." << std::endl;

	// Now draw the carpet on top of the floor
	std::cout << "Rendering carpet..." << std::endl;

	// Make the carpet slightly raised above the floor
	scaleXYZ = glm::vec3(6.0f, 0.02f, 4.0f);  // Smaller than the room, thicker than floor
	positionXYZ = glm::vec3(0.0f, 0.11f, 0.0f);  // 0.01 above the floor

	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);

	// Use the carpet texture and material
	SetShaderTexture("carpet");
	SetShaderMaterial("carpet");
	SetTextureUVScale(3.0f, 2.0f);  // Adjust for carpet size

	m_basicMeshes->DrawBoxMesh();

	// Optional: Add a carpet border/edge
	scaleXYZ = glm::vec3(6.1f, 0.025f, 4.1f);  // Slightly larger than carpet
	positionXYZ = glm::vec3(0.0f, 0.108f, 0.0f);  // Just below carpet surface

	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);

	SetShaderTexture("carpet_edge");  // Different texture for edge
	SetShaderMaterial("carpet_edge");
	SetShaderColor(0.3f, 0.2f, 0.15f, 1.0f);  // Darker color for border

	m_basicMeshes->DrawBoxMesh();

	std::cout << "Carpet rendered." << std::endl;

	/*** BACK WALL WITH MORE DEPTH ***/

	// Base wall structure
	std::cout << "Rendering back wall..." << std::endl;

	scaleXYZ = glm::vec3(30.0f, 15.0f, 0.5f);
	positionXYZ = glm::vec3(0.0f, 7.5f, -7.5f);
	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
	SetShaderTexture("wall");
	SetShaderMaterial("wall");
	SetTextureUVScale(25.0f, 15.0f);
	m_basicMeshes->DrawBoxMesh();

	

	

	// Add wall panels for more depth (wainscoting effect)
	// Lower wall panel
	scaleXYZ = glm::vec3(28.0f, 4.0f, 0.1f);  // Thin panel
	positionXYZ = glm::vec3(0.0f, 2.5f, -7.0f);  // Slightly in front of wall
	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
	SetShaderTexture("wood_panel");
	SetShaderMaterial("wood_panel");
	SetShaderColor(0.5f, 0.4f, 0.3f, 1.0f);
	SetTextureUVScale(14.0f, 2.0f);
	m_basicMeshes->DrawBoxMesh();

	// Add chair rail (horizontal divider between panels)
	scaleXYZ = glm::vec3(28.2f, 0.15f, 0.2f);
	positionXYZ = glm::vec3(0.0f, 4.5f, -6.9f);
	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
	SetShaderColor(0.7f, 0.6f, 0.5f, 1.0f);
	m_basicMeshes->DrawBoxMesh();


	// Add decorative wall sconce (light fixture) for more depth
	scaleXYZ = glm::vec3(0.5f, 1.0f, 0.3f);
	positionXYZ = glm::vec3(8.0f, 5.0f, -6.8f);  // Right side of wall
	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
	SetShaderTexture("metal");
	SetShaderMaterial("metal");
	SetShaderColor(0.8f, 0.7f, 0.6f, 1.0f);  // Brass color
	m_basicMeshes->DrawBoxMesh();

	// Add another sconce on left side
	positionXYZ = glm::vec3(-8.0f, 5.0f, -6.8f);
	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
	m_basicMeshes->DrawBoxMesh();


	// Add window or picture frame for depth (optional)
	scaleXYZ = glm::vec3(4.0f, 3.0f, 0.15f);
	positionXYZ = glm::vec3(0.0f, 8.0f, -6.9f);  // Center of wall
	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
	SetShaderTexture("picture_frame");
	SetShaderMaterial("wood_frame");
	SetShaderColor(0.4f, 0.3f, 0.2f, 1.0f);
	m_basicMeshes->DrawBoxMesh();

	// Add "glass" or picture inside frame
	scaleXYZ = glm::vec3(3.8f, 2.8f, 0.02f);
	positionXYZ = glm::vec3(0.0f, 8.0f, -6.75f);  // In front of frame
	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
	SetShaderTexture("painting");  // Or "glass" for window
	SetShaderMaterial("glass");
	SetTextureUVScale(1.0f, 1.0f);
	m_basicMeshes->DrawBoxMesh();

	std::cout << "Back wall with depth rendered." << std::endl;
;


/*** MEDIA STAND ***/

/*** THE MAIN BASE - RECTANGULAR BOX INSTEAD OF CYLINDER ***/
scaleXYZ = glm::vec3(5.0f, 0.5f, 2.5f);  // Made wider and deeper
XrotationDegrees = 0.0f;
YrotationDegrees = 0.0f;  // Changed from 90 to 0 for proper alignment
ZrotationDegrees = 0.0f;
positionXYZ = glm::vec3(0.0f, 0.25f, 0.0f);  // Lowered to ground

SetTransformations(
	scaleXYZ,
	XrotationDegrees,
	YrotationDegrees,
	ZrotationDegrees,
	positionXYZ);

SetShaderTexture("light_wood");
SetShaderMaterial("light_wood");
SetTextureUVScale(4.0f, 2.0f);  // Adjusted for rectangular shape
m_basicMeshes->DrawBoxMesh();  // Changed to BoxMesh for rectangular shape

/*** SIDE PANELS - LEFT ***/
scaleXYZ = glm::vec3(0.1f, 1.8f, 2.5f);  // Tall side panel
XrotationDegrees = 0.0f;
YrotationDegrees = 0.0f;
ZrotationDegrees = 0.0f;
positionXYZ = glm::vec3(-2.45f, 1.1f, 0.0f);  // Left side

SetTransformations(
	scaleXYZ,
	XrotationDegrees,
	YrotationDegrees,
	ZrotationDegrees,
	positionXYZ);

SetShaderTexture("light_wood");
SetShaderMaterial("light_wood");
SetTextureUVScale(1.0f, 3.0f);
m_basicMeshes->DrawBoxMesh();

/*** SIDE PANELS - RIGHT ***/
positionXYZ = glm::vec3(2.45f, 1.1f, 0.0f);  // Right side

SetTransformations(
	scaleXYZ,
	XrotationDegrees,
	YrotationDegrees,
	ZrotationDegrees,
	positionXYZ);
m_basicMeshes->DrawBoxMesh();

/*** BACK PANEL ***/
scaleXYZ = glm::vec3(5.0f, 1.8f, 0.1f);  // Full back panel
positionXYZ = glm::vec3(0.0f, 1.1f, -1.2f);  // Back side

SetTransformations(
	scaleXYZ,
	XrotationDegrees,
	YrotationDegrees,
	ZrotationDegrees,
	positionXYZ);

SetShaderTexture("light_wood");
SetShaderMaterial("light_wood");
SetTextureUVScale(4.0f, 3.0f);
m_basicMeshes->DrawBoxMesh();

/*** BOTTOM SHELF - FULL WIDTH ***/
scaleXYZ = glm::vec3(4.8f, 0.08f, 2.3f);  // Almost full width of cabinet
XrotationDegrees = 0.0f;
YrotationDegrees = 0.0f;
ZrotationDegrees = 0.0f;
positionXYZ = glm::vec3(0.0f, 0.7f, 0.0f);

SetTransformations(
	scaleXYZ,
	XrotationDegrees,
	YrotationDegrees,
	ZrotationDegrees,
	positionXYZ);

SetShaderTexture("light_wood");
SetShaderMaterial("light_wood");
SetTextureUVScale(4.0f, 2.0f);  // Adjusted texture scale
m_basicMeshes->DrawBoxMesh();

/*** MIDDLE SHELF - FULL WIDTH ***/
scaleXYZ = glm::vec3(4.8f, 0.08f, 2.3f);  // Same width as bottom shelf
positionXYZ = glm::vec3(0.0f, 1.3f, 0.0f);  // Higher position

SetTransformations(
	scaleXYZ,
	XrotationDegrees,
	YrotationDegrees,
	ZrotationDegrees,
	positionXYZ);

SetShaderTexture("light_wood");
SetShaderMaterial("light_wood");
SetTextureUVScale(4.0f, 2.0f);
m_basicMeshes->DrawBoxMesh();

/*** TOP SHELF - FULL WIDTH ***/
scaleXYZ = glm::vec3(4.8f, 0.1f, 2.3f);  // Slightly thicker top shelf
positionXYZ = glm::vec3(0.0f, 1.9f, 0.0f);  // Top of cabinet

SetTransformations(
	scaleXYZ,
	XrotationDegrees,
	YrotationDegrees,
	ZrotationDegrees,
	positionXYZ);

SetShaderTexture("light_wood");
SetShaderMaterial("light_wood");
SetTextureUVScale(4.0f, 2.0f);
m_basicMeshes->DrawBoxMesh();

/*** TV STAND SURFACE - ON TOP OF CABINET ***/
scaleXYZ = glm::vec3(3.0f, 0.05f, 1.0f);  // Smaller surface for TV
positionXYZ = glm::vec3(0.0f, 2.05f, 0.0f);  // On top of cabinet

SetTransformations(
	scaleXYZ,
	XrotationDegrees,
	YrotationDegrees,
	ZrotationDegrees,
	positionXYZ);

SetShaderColor(0.3f, 0.3f, 0.35f, 1.0f); // Dark metallic
m_basicMeshes->DrawBoxMesh();

/*** TV - SCREEN ***/
scaleXYZ = glm::vec3(1.8f, 1.0f, 0.05f); // Larger TV screen
XrotationDegrees = 0.0f;
YrotationDegrees = 0.0f;
ZrotationDegrees = 0.0f;
positionXYZ = glm::vec3(0.0f, 3.2f, 0.4f); // Higher to account for taller cabinet

SetTransformations(
	scaleXYZ,
	XrotationDegrees,
	YrotationDegrees,
	ZrotationDegrees,
	positionXYZ);

SetShaderColor(0.1f, 0.1f, 0.1f, 1.0f); // Black screen
m_basicMeshes->DrawBoxMesh();

/*** TV - BEZEL (Frame around screen) ***/
scaleXYZ = glm::vec3(1.85f, 1.05f, 0.06f); // Slightly larger than screen
positionXYZ = glm::vec3(0.0f, 3.2f, 0.405f); // Same position as screen but slightly forward

SetTransformations(
	scaleXYZ,
	XrotationDegrees,
	YrotationDegrees,
	ZrotationDegrees,
	positionXYZ);

SetShaderColor(0.2f, 0.2f, 0.25f, 1.0f); // Dark gray bezel
m_basicMeshes->DrawBoxMesh();

/*** TV - STAND (Neck/Base) ***/
scaleXYZ = glm::vec3(0.15f, 0.4f, 0.15f);
positionXYZ = glm::vec3(0.0f, 2.7f, 0.4f); // Connects screen to base

SetTransformations(
	scaleXYZ,
	XrotationDegrees,
	YrotationDegrees,
	ZrotationDegrees,
	positionXYZ);

SetShaderColor(0.35f, 0.35f, 0.4f, 1.0f); // Metallic
m_basicMeshes->DrawBoxMesh();

/*** TV - BASE (Bottom support) ***/
scaleXYZ = glm::vec3(0.5f, 0.05f, 0.3f);  // Wider base
positionXYZ = glm::vec3(0.0f, 2.5f, 0.4f); // At bottom of TV stand

SetTransformations(
	scaleXYZ,
	XrotationDegrees,
	YrotationDegrees,
	ZrotationDegrees,
	positionXYZ);

SetShaderTexture("metal");
SetShaderMaterial("metal");
SetTextureUVScale(1.0f, 4.0f);
m_basicMeshes->DrawBoxMesh();

}
	/****************************************************************/

