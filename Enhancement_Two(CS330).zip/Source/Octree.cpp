///////////////////////////////////////////////////////////////////////////////
// octree.cpp
// ============
// Spatial partitioning using octree for frustum culling
//
//  AUTHOR: Enhanced for CS-330 Final Project
///////////////////////////////////////////////////////////////////////////////

#include "Octree.h"
#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtc/type_ptr.hpp>
#include <algorithm>
#include <cmath>

// OctreeNode implementation
OctreeNode::OctreeNode(const glm::vec3& center, float halfSize, int depth, int maxDepth)
    : m_Center(center)
    , m_HalfSize(halfSize)
    , m_Depth(depth)
    , m_MaxDepth(maxDepth)
    , m_IsLeaf(true)
{
    for (int i = 0; i < 8; i++)
        m_Children[i] = nullptr;
}

void OctreeNode::Insert(SceneObject* object)
{
    // If this is a leaf node and we haven't reached max depth
    if (m_IsLeaf && m_Depth < m_MaxDepth)
    {
        // Split if we have too many objects or this is a new node
        if (m_Objects.size() >= 4)
        {
            Split();
        }
    }
    
    // If we're not a leaf, find the right child
    if (!m_IsLeaf)
    {
        int childIndex = GetChildIndex(object->bounds.center);
        if (childIndex >= 0 && childIndex < 8)
        {
            m_Children[childIndex]->Insert(object);
            return;
        }
    }
    
    // Add to this node (either leaf or max depth reached)
    m_Objects.push_back(object);
}

void OctreeNode::Split()
{
    if (!m_IsLeaf)
        return;
    
    m_IsLeaf = false;
    float childHalfSize = m_HalfSize * 0.5f;
    
    // 8 children with offsets
    glm::vec3 offsets[8] = {
        glm::vec3(-1, -1, -1), glm::vec3( 1, -1, -1),
        glm::vec3(-1,  1, -1), glm::vec3( 1,  1, -1),
        glm::vec3(-1, -1,  1), glm::vec3( 1, -1,  1),
        glm::vec3(-1,  1,  1), glm::vec3( 1,  1,  1)
    };
    
    for (int i = 0; i < 8; i++)
    {
        glm::vec3 childCenter = m_Center + (offsets[i] * childHalfSize);
        m_Children[i] = new OctreeNode(childCenter, childHalfSize, m_Depth + 1, m_MaxDepth);
    }
    
    // Redistribute existing objects to children
    std::vector<SceneObject*> tempObjects = m_Objects;
    m_Objects.clear();
    
    for (SceneObject* obj : tempObjects)
    {
        int childIndex = GetChildIndex(obj->bounds.center);
        if (childIndex >= 0 && childIndex < 8)
        {
            m_Children[childIndex]->Insert(obj);
        }
        else
        {
            m_Objects.push_back(obj);
        }
    }
}

int OctreeNode::GetChildIndex(const glm::vec3& point) const
{
    int index = 0;
    if (point.x >= m_Center.x) index |= 1;
    if (point.y >= m_Center.y) index |= 2;
    if (point.z >= m_Center.z) index |= 4;
    return index;
}

bool OctreeNode::IntersectsFrustum(const BoundingBox& bounds, const glm::mat4& viewProjectionMatrix) const
{
    // Transform bounding box corners to clip space
    glm::vec3 corners[8] = {
        bounds.center + glm::vec3(-bounds.halfSize.x, -bounds.halfSize.y, -bounds.halfSize.z),
        bounds.center + glm::vec3( bounds.halfSize.x, -bounds.halfSize.y, -bounds.halfSize.z),
        bounds.center + glm::vec3(-bounds.halfSize.x,  bounds.halfSize.y, -bounds.halfSize.z),
        bounds.center + glm::vec3( bounds.halfSize.x,  bounds.halfSize.y, -bounds.halfSize.z),
        bounds.center + glm::vec3(-bounds.halfSize.x, -bounds.halfSize.y,  bounds.halfSize.z),
        bounds.center + glm::vec3( bounds.halfSize.x, -bounds.halfSize.y,  bounds.halfSize.z),
        bounds.center + glm::vec3(-bounds.halfSize.x,  bounds.halfSize.y,  bounds.halfSize.z),
        bounds.center + glm::vec3( bounds.halfSize.x,  bounds.halfSize.y,  bounds.halfSize.z)
    };
    
    // Simple frustum culling: check if any corner is inside the view frustum
    for (int i = 0; i < 8; i++)
    {
        glm::vec4 clipPos = viewProjectionMatrix * glm::vec4(corners[i], 1.0f);
        
        // Check if the point is inside the clip space cube
        if (clipPos.w != 0.0f)
        {
            glm::vec3 ndc = glm::vec3(clipPos) / clipPos.w;
            if (ndc.x >= -1.0f && ndc.x <= 1.0f &&
                ndc.y >= -1.0f && ndc.y <= 1.0f &&
                ndc.z >= -1.0f && ndc.z <= 1.0f)
            {
                return true; // At least one corner is visible
            }
        }
    }
    return false; // All corners are outside the frustum
}

bool OctreeNode::PointInBounds(const glm::vec3& point) const
{
    return (point.x >= m_Center.x - m_HalfSize && point.x <= m_Center.x + m_HalfSize &&
            point.y >= m_Center.y - m_HalfSize && point.y <= m_Center.y + m_HalfSize &&
            point.z >= m_Center.z - m_HalfSize && point.z <= m_Center.z + m_HalfSize);
}

void OctreeNode::GetVisibleObjects(const glm::mat4& viewProjectionMatrix, std::vector<SceneObject*>& outVisible)
{
    // If this node is entirely outside the frustum, skip it
    if (m_Objects.empty() && m_IsLeaf)
        return;
    
    // Check if this node's bounding box intersects the frustum
    BoundingBox nodeBounds(m_Center, glm::vec3(m_HalfSize));
    if (!IntersectsFrustum(nodeBounds, viewProjectionMatrix))
        return;
    
    // If leaf, add all objects
    if (m_IsLeaf)
    {
        for (SceneObject* obj : m_Objects)
        {
            // Additional per-object frustum check for accuracy
            if (IntersectsFrustum(obj->bounds, viewProjectionMatrix))
            {
                outVisible.push_back(obj);
            }
        }
        return;
    }
    
    // Recurse into children
    for (int i = 0; i < 8; i++)
    {
        if (m_Children[i])
        {
            m_Children[i]->GetVisibleObjects(viewProjectionMatrix, outVisible);
        }
    }
    
    // Also check objects stored at this level (if any)
    for (SceneObject* obj : m_Objects)
    {
        if (IntersectsFrustum(obj->bounds, viewProjectionMatrix))
        {
            outVisible.push_back(obj);
        }
    }
}

void OctreeNode::GetAllObjects(std::vector<SceneObject*>& outObjects)
{
    for (SceneObject* obj : m_Objects)
    {
        outObjects.push_back(obj);
    }
    
    if (!m_IsLeaf)
    {
        for (int i = 0; i < 8; i++)
        {
            if (m_Children[i])
            {
                m_Children[i]->GetAllObjects(outObjects);
            }
        }
    }
}

void OctreeNode::Clear()
{
    for (SceneObject* obj : m_Objects)
    {
        // Note: We don't delete the objects here as they're managed elsewhere
    }
    m_Objects.clear();
    
    if (!m_IsLeaf)
    {
        for (int i = 0; i < 8; i++)
        {
            if (m_Children[i])
            {
                m_Children[i]->Clear();
                delete m_Children[i];
                m_Children[i] = nullptr;
            }
        }
        m_IsLeaf = true;
    }
}

// Octree implementation
Octree::Octree(const glm::vec3& center, float halfSize, int maxDepth)
    : m_MaxDepth(maxDepth)
{
    m_Root = new OctreeNode(center, halfSize, 0, maxDepth);
}

Octree::~Octree()
{
    Clear();
    delete m_Root;
}

void Octree::Insert(SceneObject* object)
{
    if (m_Root)
        m_Root->Insert(object);
}

void Octree::GetVisibleObjects(const glm::mat4& viewProjectionMatrix, std::vector<SceneObject*>& outVisible)
{
    if (m_Root)
        m_Root->GetVisibleObjects(viewProjectionMatrix, outVisible);
}

void Octree::GetAllObjects(std::vector<SceneObject*>& outObjects)
{
    if (m_Root)
        m_Root->GetAllObjects(outObjects);
}

void Octree::Clear()
{
    if (m_Root)
        m_Root->Clear();
}