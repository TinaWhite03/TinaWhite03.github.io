///////////////////////////////////////////////////////////////////////////////
// octree.h
// ============
// Spatial partitioning using octree for frustum culling
//
//  AUTHOR: Enhanced for CS-330 Final Project
///////////////////////////////////////////////////////////////////////////////

#pragma once

#include <vector>
#include <glm/glm.hpp>

// Forward declaration
class SceneObject;

// Simple bounding box structure
struct BoundingBox
{
    glm::vec3 center;
    glm::vec3 halfSize;
    
    BoundingBox() : center(0.0f), halfSize(0.0f) {}
    BoundingBox(const glm::vec3& c, const glm::vec3& h) : center(c), halfSize(h) {}
};

// Scene object container with transformation and render info
struct SceneObject
{
    std::string name;
    std::string textureTag;
    std::string materialTag;
    std::string meshType;  // "box", "sphere", "cylinder", "plane"
    
    glm::vec3 scale;
    glm::vec3 position;
    glm::vec3 rotation;  // Euler angles in degrees
    
    BoundingBox bounds;
    bool visible;
    
    SceneObject() : scale(1.0f), position(0.0f), rotation(0.0f), visible(true) {}
};

// Octree node class
class OctreeNode
{
public:
    // Constructor
    OctreeNode(const glm::vec3& center, float halfSize, int depth = 0, int maxDepth = 4);
    
    // Insert an object into the octree
    void Insert(SceneObject* object);
    
    // Get visible objects within camera frustum
    void GetVisibleObjects(const glm::mat4& viewProjectionMatrix, std::vector<SceneObject*>& outVisible);
    
    // Get all objects (for debugging)
    void GetAllObjects(std::vector<SceneObject*>& outObjects);
    
    // Clear the octree
    void Clear();
    
private:
    glm::vec3 m_Center;
    float m_HalfSize;
    int m_Depth;
    int m_MaxDepth;
    bool m_IsLeaf;
    
    std::vector<SceneObject*> m_Objects;
    OctreeNode* m_Children[8];
    
    // Split the current node into 8 children
    void Split();
    
    // Get child index for an object's center
    int GetChildIndex(const glm::vec3& point) const;
    
    // Check if a bounding box intersects the camera frustum
    bool IntersectsFrustum(const BoundingBox& bounds, const glm::mat4& viewProjectionMatrix) const;
    
    // Test if a point is inside a bounding box
    bool PointInBounds(const glm::vec3& point) const;
};

// Main Octree class
class Octree
{
public:
    Octree(const glm::vec3& center, float halfSize, int maxDepth = 4);
    ~Octree();
    
    void Insert(SceneObject* object);
    void GetVisibleObjects(const glm::mat4& viewProjectionMatrix, std::vector<SceneObject*>& outVisible);
    void GetAllObjects(std::vector<SceneObject*>& outObjects);
    void Clear();
    
private:
    OctreeNode* m_Root;
    int m_MaxDepth;
};